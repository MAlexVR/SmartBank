export const lista = {
  cargos: [
    {
      id: "123131321",
      type: "Restaurante",
      value: "$450.00",
      date: "11 JUN",
      from: "Pizza Hut",
    },
    {
      id: "4564654",
      type: "Utilidades",
      value: "$340.00",
      date: "9 JUN",
      from: "Cuenta de luz",
    },
    {
      id: "65445",
      type: "Salud",
      value: "$150.00",
      date: "8 JUN",
      from: "Farmacias A.",
    },
    {
      id: "656565",
      type: "Transporte",
      value: "$55.00",
      date: "8 JUN",
      from: "Uber",
    },
    {
      id: "926544",
      type: "Otros",
      value: "$1,500.00",
      date: "5 JUN",
      from: "Amazon",
    },
  ],
};
